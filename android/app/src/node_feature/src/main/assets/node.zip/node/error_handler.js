
process.on('uncaughtException', (err) => {
  process.stderr.write(`${err.stack}\n`);
  process.exit(1);
});

process.on('unhandledRejection', (err) => {
  process.stderr.write(`${err.stack}\n`);
});

console.error = (...args) => {
  process.stderr.write(`${args.join(' ')}\n`);
};
